exports.auth = require('./auth');
exports.league = require('./league');
exports.team = require('./team');
exports.player = require('./player');
exports.settings = require('./settings');
exports.registration = require('./registration');
exports.seasons = require('./seasons');
exports.games = require('./games');
